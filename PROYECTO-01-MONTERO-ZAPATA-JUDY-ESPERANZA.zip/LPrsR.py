#LISTADO 20 PEORES RESEÑAS. CONSIGNIA 2



from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches


lista=[]

for ID in lifestore_products:
  suma=0
  cont=0
  devoluciones=0

  for sale in lifestore_sales:
    if sale[1]==ID[0]:
      cont=cont+1
      suma=sale[2]+suma
      devoluciones+=sale[4]

  if suma!=0:
    prom=suma/cont
    lista.append([ID[0],prom,devoluciones,cont])

lista_ordenada=[]

while lista:
  
  m=lista[0][1]
  minimo=lista[0]

  for elemento in range(len(lista)):
  
    if lista[elemento][1] < m:
      m=lista[elemento][1]
      minimo=lista[elemento]
    if lista[elemento][1] == m and lista[elemento]<minimo:
      m=lista[elemento][1]
      minimo=lista[elemento]
      
  lista_ordenada.append(minimo)  
  lista.remove(minimo)
#print("------")

lista8=[]

for i in range(len(lista_ordenada)):
  contador=0
  while lista_ordenada[i][0]!=lifestore_products[contador][0]:
    contador=contador+1
  lista8.append([lista_ordenada[i][0],lifestore_products[contador][1],lista_ordenada[i][1],lista_ordenada[i][2],lista_ordenada[i][3]])


 
