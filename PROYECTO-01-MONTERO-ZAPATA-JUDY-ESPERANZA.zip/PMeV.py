# PRODUCTOS Menos VENDIDOS 
#CONSIGNA (1)


from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

#Este Paso cuenta cuántas veces se vendió un determinado producto. Se almacena en la lista "lista"

lista=[]

for ID in lifestore_products:
  cont=0

  for sale in lifestore_sales:
    if sale[1]==ID[0]:
      cont=cont+1

  
  lista.append([ID[0],cont])

#print(lista)
#Este paso ordena la lista de ventas de menor a mayor.Se almacena en la lista "lista_ordenada"

lista_ordenada=[]

while lista:
  
  m=lista[0][1]
  minimo=lista[0]

  for elemento in range(len(lista)):
  
    if lista[elemento][1] < m:
      m=lista[elemento][1]
      minimo=lista[elemento]
    if lista[elemento][1] == m and lista[elemento]<minimo:
      m=lista[elemento][1]
      minimo=lista[elemento]
      
  lista_ordenada.append(minimo)  
  lista.remove(minimo)


lista3=[]
for i in range(len(lista_ordenada)):
  contador=0
  while lista_ordenada[i][0]!=lifestore_products[contador][0]:
    contador=contador+1
  lista3.append([lista_ordenada[i][0],lifestore_products[contador][1],lista_ordenada[i][1]])
