# PRODUCTOS MÁS BUSCADOS
#CONSIGNA (1)


from lifestore_file import lifestore_products  
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

#Este Paso cuenta cuántas veces se vendió un determinado producto

contador=0
lista=[] #Lista que almacena el número de busquedas

for search in range(len(lifestore_searches)):
  contador=contador+1
  
  if lifestore_searches[search][1]!=lifestore_searches[search-1][1]:
    lista.append([lifestore_searches[search-1][1],contador])
    contador=0 
      
  if lifestore_searches[search]==lifestore_searches[-1]:
    lista.append([lifestore_searches[search][1],contador+1])
    lista.remove(lista[0])

#Este paso ordena la lista de busqueas de mayor a menor

lista_ordenada=[] #lista de busquedas ya ordenadas

while lista:
  
  m=lista[0][1]
  maximo=lista[0]

  for elemento in range(len(lista)):
  
    if lista[elemento][1] > m:
      m=lista[elemento][1]
      maximo=lista[elemento]
    if lista[elemento][1] == m and lista[elemento]<maximo:
      m=lista[elemento][1]
      maximo=lista[elemento]
      
  lista_ordenada.append(maximo)  
  lista.remove(maximo)

#Busca el producto y lo asigna a su ID

#x=int(input("¿Cuántos productos desea ver?: "))

#if x>56 or x<=0:
 # x=56
  #print("NOTA: Se le mostrarán únicamente productos con busquedas") #Dado que existen sólo 56 productos con busquedas

lista2=[]

for i in range(len(lista_ordenada)):
  contador=0
  while lista_ordenada[i][0]!=lifestore_products[contador][0]:
    contador=contador+1
    
  lista2.append([lista_ordenada[i][0],lifestore_products[contador][1],lista_ordenada[i][1]])



