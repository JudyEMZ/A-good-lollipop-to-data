



from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

Lista_separada=[]


for i in range(len(lifestore_sales)):
  contador=0
  while lifestore_sales[i][1]!=lifestore_products[contador][0]:
    contador=contador+1
    
  Lista_separada.append([lifestore_sales[i][1],lifestore_products[contador][2],int(lifestore_sales[i][3][3:5]),int(lifestore_sales[i][3][6:10]),lifestore_sales[i][0],lifestore_sales[i][4]])

#print(Lista_separada)

lista=[]

for j in range(1,12+1):
    suma=0
    cont=0
    for i in Lista_separada:
        if i[2]==j:
          if i[5]==0:
            suma+=i[1]
            cont+=1
    
    lista.append([j,suma,cont])

lista_ordenada=[]

while lista:
  
  m=lista[0][1]
  maximo=lista[0]

  for elemento in range(len(lista)):
  
    if lista[elemento][1] > m:
      m=lista[elemento][1]
      maximo=lista[elemento]
    if lista[elemento][1] == m and lista[elemento]<maximo:
      m=lista[elemento][1]
      maximo=lista[elemento]
      
  lista_ordenada.append(maximo)  
  lista.remove(maximo)


lista12=[]

for elemento in lista_ordenada:
  lista12.append([elemento[0],elemento[1]])