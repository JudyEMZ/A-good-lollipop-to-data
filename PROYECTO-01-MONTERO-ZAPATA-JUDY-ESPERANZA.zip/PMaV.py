# PRODUCTOS MÁS VENDIDOS 
#CONSIGNA (1)


from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

# FASE 1: Este Paso cuenta cuántas veces se vendió un determinado producto. Se almacena en la lista "lista"

contador=0
lista=[] #Lista de ventas por producto

for sale in range(len(lifestore_sales)):
  contador=contador+1
  
  if lifestore_sales[sale][1]!=lifestore_sales[sale-1][1]:
    lista.append([lifestore_sales[sale-1][1],contador])
    contador=0 
      
  if lifestore_sales[sale]==lifestore_sales[-1]:
    lista.append([lifestore_sales[sale][1],contador+1])
    lista.remove(lista[0])

#Este paso ordena la lista de ventas de mayor a menor.Se almacena en la lista "lista_ordenada"

lista_ordenada=[]

while lista:
  
  m=lista[0][1]
  maximo=lista[0]

  for elemento in range(len(lista)):
  
    if lista[elemento][1] > m:
      m=lista[elemento][1]
      maximo=lista[elemento]
    if lista[elemento][1] == m and lista[elemento]<maximo:
      m=lista[elemento][1]
      maximo=lista[elemento]
      
  lista_ordenada.append(maximo)  
  lista.remove(maximo)

#Este paso te muestra el resultado final  

#x=int(input("\n ¿Cuántos productos desea ver?: ")) #se le pide al usuario ingresar un número

#if x>43 or x<=0:
 # x=42   
  #print("NOTA: Se le mostrarán únicamente productos con ventas") #Dado que existen sólo 42 productos con ventas se pone esta restricción

lista1=[]

for i in range(len(lista_ordenada)):
  contador=0
  while lista_ordenada[i][0]!=lifestore_products[contador][0]:
    contador=contador+1


  lista1.append([lista_ordenada[i][0],lifestore_products[contador][1],lista_ordenada[i][1]])

#lista1



