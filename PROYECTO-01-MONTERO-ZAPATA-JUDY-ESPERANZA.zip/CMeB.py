#MENORES BUSQUEDAS POR CATEGORIA

from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

lista_categoria=[]

for i in range(len(lifestore_searches)):
  contador=0
  while lifestore_searches[i][1]!=lifestore_products[contador][0]:
    contador=contador+1
    
  lista_categoria.append([lifestore_searches[i][0],
                          lifestore_products[contador][3],
                          lifestore_searches[i][1]])
  
#print(lista_categoria)

contador=0
lista=[] #Lista de ventas por producto

for i in range(len(lista_categoria)):
  contador=contador+1
  
  if lista_categoria[i][1]!=lista_categoria[i-1][1]:
    lista.append([lista_categoria[i-1][1],contador])
    contador=0 
      
  if lista_categoria[i]==lista_categoria[-1]:
    lista.append([lista_categoria[i][1],contador+1])
    lista.remove(lista[0])
    
#print(lista)

lista_ordenada=[]

while lista:
  
  m=lista[0][1]
  minimo=lista[0]

  for elemento in range(len(lista)):
  
    if lista[elemento][1] < m:
      m=lista[elemento][1]
      minimo=lista[elemento]
    if lista[elemento][1] == m and lista[elemento]<minimo:
      m=lista[elemento][1]
      minimo=lista[elemento]
      
  lista_ordenada.append(minimo)  
  lista.remove(minimo)

lista6=lista_ordenada








