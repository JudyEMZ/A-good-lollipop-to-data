

from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

Lista_separada=[]


for i in range(len(lifestore_sales)):
  contador=0
  while lifestore_sales[i][1]!=lifestore_products[contador][0]:
    contador=contador+1
    
  Lista_separada.append([lifestore_sales[i][1],lifestore_products[contador][2],int(lifestore_sales[i][3][3:5]),int(lifestore_sales[i][3][6:10]),lifestore_sales[i][0],lifestore_sales[i][4]])



suma=0
cont=0
for elemento in Lista_separada:
  if elemento[5]==0:
    suma+=elemento[1]
    cont+=1

suma=0
cont=0
for elemento in Lista_separada:
  if elemento[5]==0:
    suma+=elemento[1]
    cont+=1