
msg= """                                  
Bienvenido a la plataforma de lifestore,
su tienda virtual favorita 
                                        
      Inicie sesión para comenzar      
                                        
"""

msg2="""
        !Has sido resgistrado exitosamente!

  Por favor vuelva ingresar con su nuevo usuario:
  """
print(msg)

#Aquí empieza el log in de Usuario

Usuarios=[["Javier", "1234"],["Intruso","3456"],["Judy","1111"],["1","1"]]

#Se valida el input con un status, status =0 (inicio) 
status=0 
while status==0: # El bucle while sirve para verificar el status del usuario y ver si se ha registrado alguien nuevo
  admin=input("Nombre de usuario: ") #Se le pide al usuario que ingrese sus datos
  contraseña=input("Password: ")
 
  for usuario in Usuarios:
    if admin==usuario[0] and contraseña==usuario[1]:
      status=1 #Si los datos ingresados son correctos el status es 1, se ha verificado que el usuario existe
      break
    
  if status==0:
    print("Usuario no registrado") #Si el status no cambia, pide un registro
    respuesta=input("¿Desea agregar un usuario nuevo?(si/no) : ") 
    if respuesta=="si":   #Pasos cuando el usuario incia un registro
      admin=input("Nombre de usuario nuevo : ")   
      contraseña=input("Password: ")              
      Usuarios.append([admin,contraseña])         # Se añade a la lista de usuarios 
      print(msg2)                                
    elif respuesta=="no":       #Pasos cuando el usuario no quiere regisrarse                  
      msg2="""
        Saliendo del programa...                 
        
                      Adiós"""
      print(msg2)
      status=2
    else:  
      print("Error al ingresar datos")   #Si hay un ingreso al input distinto de si o no, arroja un error.
      
#Si el usuario existe y se le muestra el menu de opciones

if status==1:
  #menu principal
  msg=""" 
    Hola Administrador. . .

        Eliga la opción que desee ver: 

  Selecciona 1 , 2 o 3 y presiona enter:

  1: Productos más vendidos y productos rezagados:
  2: Productos por reseña en el servicio:
  3: Total de ingresos y ventas promedio mensuales,
    total anual y meses con más ventas al año:
  
  Escriba "salir" para cerrar el programa.
""" 
  #se verifican las opciones del usuario
  opcion=0  #Se crea la varible opcion para verificar el input del usuario

  while opcion!="salir":    #El menú se mostrará hasta que el usuario escriba salir
    print(msg)
    opcion=input("Opción: ")  #input para escoger el segundo menú de opciones
    #Se verifican las opciones
    if opcion=="1":
      #bucle 2, verifica opciones del segundo menú
      opcion2=0
      while opcion2!="salir": 
        msg=""" 
    Productos más vendidos y productos rezagados
            
      Selecciona 1, 2, 3 o 4 y presiona enter:

  1: Productos con mayores ventas:
  2: Productos con mayores busquedas:
  3: Productos con menores ventas:
  4: Productos con menores busquedas:
  5: Categoría con menos ventas:
  6: Categoría con menos busquedas:

  Escriba "salir" para cerrar el programa.
        
        """
        print(msg)
        opcion2=input("Opción: ")
        #Aqui se mostrarán los resultados dependiendo del menú que el usuario eliga
        if opcion2=="1":
          from PMaV import lista1
          print("\nPRODUCTOS CON MAYORES VENTAS\n")
          for j in range(20):
            print("\n ------ \n")
            print("( ",j+1," )")
            print("ID de producto: ", lista1[j][0])
            print("Nombre del producto: ",lista1[j][1])
            print("Ventas totales: ", lista1[j][2])

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")

          if opcion3!="1":
            opcion="salir"
            break

        elif opcion2=="2":
          from PMaB import lista2
          print("\nPRODUCTOS CON MAYORES BÚSQUEDAS\n")
          for j in range(20):
            print("\n ------ \n")
            print("( ",j+1," )")
            print("ID de producto: ", lista2[j][0])
            print("Nombre del producto: ",lista2[j][1])
            print("Búsquedas totales: ", lista2[j][2])

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break
            
        elif opcion2=="3":
          from PMeV import lista3
          print("\nPRODUCTOS CON MENORES VENTAS\n")
          for j in range(20):
            print("\n ------ \n")
            print("( ",j+1," )")
            print("ID de producto: ", lista3[j][0])
            print("Nombre del producto: ",lista3[j][1])
            print("Ventas totales: ", lista3[j][2])

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break
         
        elif opcion2=="4":
          from PMeB import lista4 #productos sin busquedas
          print("\nPRODUCTOS CON MENORES BÚSQUEDAS\n")
          for j in range(20):
            print("\n ------ \n")
            print("( ",j+1," )")
            print("ID de producto: ", lista4[j][0])
            print("Nombre del producto: ",lista4[j][1])
            print("Búsquedas totales: ", lista4[j][2])
          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break

        elif opcion2=="5":
          from CMeV import lista5 #Ventas por categoria
          print("\nCATEGORÍA CON MENOS VENTAS\n")
          for j in range(len(lista5)):
            print("( ",j+1," )")
            print("Categoria: ", lista5[j][0])
            print("Ventas totales: ",lista5[j][1])

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break
         
        elif opcion2=="6":
          from CMeB import lista6 #busquedas por categoria
          print("\nCATEGORÍA CON MENOS BÚSQUEDAS\n")
          for j in range(len(lista6)):
            print("( ",j+1," )")
            print("Categoria: ", lista6[j][0])
            print("Busquedas totales: ",lista6[j][1])

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break
          
        elif opcion2!="salir":
          print("¡Ups! no se reconoce la entrada \n Intentalo de nuevo")

      opcion="salir" #Fin bucle dos

    elif opcion=="2":
      #bucle 2, verifica opciones del segundo menú eligiendo opción 2 en el menú anterior
      opcion2=0
      while opcion2!="salir": 
        msg=""" 
    Productos por reseña en el servicio
          
  Selecciona 1 , 2 o 3 y presiona enter:

  1: Productos con mejores reseñas:
  2: Productos con peores reseñas:

  Escriba "salir" para cerrar el programa.

      """
        print(msg)
        opcion2=input("Opción: ")

        if opcion2=="1":
          from LMjsR import lista7 #Lista mejores reseñas
          print("\nPRODUCTOS CON MEJORES RESEÑAS\n")
          for j in range(20):
            print("( ",j+1," )")
            print("ID de producto: ", lista7[j][0])
            print("Nombre del producto: ",lista7[j][1])
            print("Reseña promedio: ", lista7[j][2])
            print("Devoluciones Totales: ", lista7[j][3],"de ", lista7[j][4], " venta(s)")  

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break
        
        elif opcion2=="2":
          from LPrsR import lista8 #Lista peores reseñas
          print("\nPRODUCTOS CON PEORES RESEÑAS\n")
          for j in range(20):
              print("( ",j+1," )")
              print("ID de producto: ", lista8[j][0])
              print("Nombre del producto: ",lista8[j][1])
              print("Reseña promedio: ", lista8[j][2])
              print("Devoluciones Totales: ", lista8[j][3],"de ", lista8[j][4], " venta(s)")  

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break
          
        elif opcion2!="salir":
          print("¡Ups! no se reconoce la entrada \n Intentalo de nuevo")
      # no se reconoce ninguna entrada, vuelve a ejecutar el segundo while
      opcion="salir" #Fin bucle dos
       
    elif opcion=="3":
      opcion2=0
      while opcion2!="salir": ##bucle2, verifica opciones del segundo menú eligiendo opción 2 en el menú anterior
    
        msg=""" 
      Total de ingresos y ventas promedio mensuales,
      total anual y meses con más ventas al año
          
    Selecciona 1 o 2 y presiona enter:

    1: Total de ingresos y ventas mensuales:
    2: Ingreso y venta promedio mensual:
       Total ingreso y venta anual:
    3: Top de meses con más ventas:
    4: Top de meses con más ingreso:

    Escriba "salir" para cerrar el programa.
      """
        print(msg)
        opcion2=input("Opción: ")

        if opcion2=="1":
          from IyVM import lista9 #Ingresos y ventas mensuales
          print("\nTOTAL DE INGRESOS Y VENTAS MENSUALES\n")
          for j in lista9:
            print("\n Mes: ",j[0],"\n Ingreso total: $",j[1],"\n Ventas totales: ",j[2])

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break

        elif opcion2=="2":
          from IyVP import suma #Ingresos y ventas promedio
          from IyVP import cont
          print( "\n* INGRESOS Y VENTAS PROMEDIO MENSUAL EN EL 2020 \n")
          print("Ingreso promedio mensual: $",suma/8)
          print("Venta promedio mensual: ",int(cont/8))
          print( "\n* INGRESO Y VENTA TOTAL ANUAL EN EL 2020 \n")
          print("Ingreso total anual: $",suma)
          print("Venta total anual: ",cont)

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break

        elif opcion2=="3":
          from TopV import lista11 #Top meses con mayores ventas
          print("\nTOP MESES CON MÁS VENTAS\n")
          for j in lista11:
            print("\n Mes: ",j[0],"\nVentas totales: ", j[1])
          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")

          if opcion3!="1":
            opcion="salir"
            break

        elif opcion2=="4":
          from TopI import lista12 #Top meses con mayores ingresos
          print("\nTOP MESES CON MÁS INGRESO\n")
          for j in lista12:
            print("\n Mes: ",j[0],"\nIngresos totales: $", j[1])

          print("\n ¿Desea volver la menú?: \n1: si:\n2: no:")
          opcion3=input("Opción: ")
          if opcion3!="1":
            opcion="salir"
            break
            
        elif opcion2!="salir":
          print("Algo no ha salido bien")

    
    elif opcion!="salir":
      print("OPCION NO ENCONTRADA, vuelve a intentarlo")  #si no se verifica ninguna opción repite el menú 1
    
  msg2="""
        Saliendo del programa...  
        
                      Adiós"""

  print(msg2)  #Mensaje cuando se sale completamente del bucle
  

  
  
  
    
  



